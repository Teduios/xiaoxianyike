//
//  BeautifulViewController.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeautifulViewController : UIViewController
+ (UINavigationController *)defaultBeautifulNavi;
@end
