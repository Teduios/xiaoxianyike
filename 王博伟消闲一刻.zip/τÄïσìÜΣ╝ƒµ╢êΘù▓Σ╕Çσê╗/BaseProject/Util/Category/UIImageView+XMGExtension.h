//
//  UIImageView+XMGExtension.h
//  3期-百思不得姐
//
//  Created by xiaomage on 15/9/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (XMGExtension)
/**
 * 设置头像
 */
- (void)setHeader:(NSString *)url;
@end
