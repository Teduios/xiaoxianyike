//
//  BeautifulNetManager.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "BeautifulModel.h"
@interface BeautifulNetManager : BaseNetManager
+ (id)getBeautifulWomanForPage:(NSInteger)page completionHandle:(void(^)(BeautifulModel *model, NSError *error))complete;

@end
