//
//  BeautifulNetManager.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BeautifulNetManager.h"

@implementation BeautifulNetManager
+ (id)getBeautifulWomanForPage:(NSInteger)page completionHandle:(void(^)(BeautifulModel *model, NSError *error))complete{
    NSString *path=@"http://box.dwstatic.com/apiAlbum.php";
    NSDictionary *params=@{@"action":@"l", @"albumsTag":@"beautifulWoman", @"p":@(page), @"v":@"77", @"OSType":@"iOS8.2", @"versionName":@"2.1.7"};
    return [self GET:path parameters:params completionHandler:^(id responseObj, NSError *error) {
        complete([BeautifulModel objectWithKeyValues:responseObj],error);
    }];
}

@end
