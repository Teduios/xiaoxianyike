//
//  BeautifulModel.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BeautifulModel.h"

@implementation BeautifulModel
//特殊规定 data对应的值 由特殊类解析
+ (NSDictionary *)objectClassInArray{
    return @{@"data": [BeautifulDataModel class]};
}

@end
@implementation BeautifulDataModel

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"desc": @"description"};
}

@end
