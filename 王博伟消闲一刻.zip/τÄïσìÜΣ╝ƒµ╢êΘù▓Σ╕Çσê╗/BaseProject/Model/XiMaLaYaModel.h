//
//  XiMaLaYaModel.h
//  BaseProject
//
//  Created by tarena on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#ifndef XiMaLaYaModel_h
#define XiMaLaYaModel_h

#import "AlbumModel.h"
#import "RankingListModel.h"


#endif /* XiMaLaYaModel_h */
