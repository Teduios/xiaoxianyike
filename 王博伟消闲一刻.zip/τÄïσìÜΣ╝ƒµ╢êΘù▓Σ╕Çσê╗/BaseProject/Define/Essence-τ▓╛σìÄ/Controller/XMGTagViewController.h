//
//  XMGTagViewController.h
//  
//
//
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGTagViewController : UITableViewController

@end
