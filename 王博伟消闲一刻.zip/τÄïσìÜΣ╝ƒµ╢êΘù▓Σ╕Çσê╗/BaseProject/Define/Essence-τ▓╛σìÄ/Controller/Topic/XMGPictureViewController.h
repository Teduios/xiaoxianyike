//
//  XMGPictureViewController.h
//
//  
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGTopicViewController.h"

@interface XMGPictureViewController : XMGTopicViewController

@end
