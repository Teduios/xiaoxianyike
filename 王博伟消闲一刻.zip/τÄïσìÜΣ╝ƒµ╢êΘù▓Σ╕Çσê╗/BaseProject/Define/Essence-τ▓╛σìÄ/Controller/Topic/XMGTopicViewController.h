//
//  XMGTopicViewController.h
//
//  
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMGTopic.h"

@interface XMGTopicViewController : UITableViewController
/** 帖子的类型 */
- (XMGTopicType)type;
//@property (nonatomic, assign) XMGTopicType type;
//@property (nonatomic, assign, readonly) XMGTopicType type;
@end

