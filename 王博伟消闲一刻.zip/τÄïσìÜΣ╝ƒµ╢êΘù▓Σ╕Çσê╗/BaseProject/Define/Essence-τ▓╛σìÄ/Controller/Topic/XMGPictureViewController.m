//
//  XMGPictureViewController.m
//
//  
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGPictureViewController.h"

@implementation XMGPictureViewController

- (XMGTopicType)type
{
    return XMGTopicTypePicture;
}
@end
