//
//  XMGWordViewController.m
//  
//
//
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGWordViewController.h"

@implementation XMGWordViewController

- (XMGTopicType)type
{
    return XMGTopicTypeWord;
}

@end
