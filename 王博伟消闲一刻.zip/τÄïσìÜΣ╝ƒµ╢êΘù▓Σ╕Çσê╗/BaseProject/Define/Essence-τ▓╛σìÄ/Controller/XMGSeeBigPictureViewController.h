//
//  XMGSeeBigPictureViewController.h
//
//
//  
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMGTopic;

@interface XMGSeeBigPictureViewController : UIViewController
/** 帖子模型 */
@property (nonatomic, strong) XMGTopic *topic;
@end
