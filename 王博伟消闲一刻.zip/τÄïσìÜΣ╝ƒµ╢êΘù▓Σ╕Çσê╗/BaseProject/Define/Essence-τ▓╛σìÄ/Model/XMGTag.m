//
//  XMGTag.m
//
//
//  .
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGTag.h"

@implementation XMGTag

@end
