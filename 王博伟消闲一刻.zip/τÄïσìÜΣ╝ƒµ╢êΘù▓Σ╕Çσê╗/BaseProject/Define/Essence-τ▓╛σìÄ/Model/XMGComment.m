//
//  XMGComment.m
//
//
//  .
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGComment.h"

@implementation XMGComment

@end
