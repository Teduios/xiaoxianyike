//
//  BeautifulViewModel.m
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BeautifulViewModel.h"

@implementation BeautifulViewModel
- (NSInteger)rowNumber{
    return self.dataArr.count;
}
- (void)refreshDataCompleteHandle:(void (^)(NSError *))complete{
    _page = 1;
    [self getDataCompleteHandle:complete];
}
- (void)getMoreDataCompleteHandle:(void (^)(NSError *))complete{
    _page += 1;
    [self getDataCompleteHandle:complete];
}
- (void)getDataCompleteHandle:(void (^)(NSError *))complete{
    [BeautifulNetManager getBeautifulWomanForPage:_page completionHandle:^(BeautifulModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data];
        complete(error);
    }];
}
- (NSURL *)iconForRow:(NSInteger)row{
    BeautifulDataModel *data = self.dataArr[row];
    return [NSURL URLWithString:data.coverUrl];
}
@end
