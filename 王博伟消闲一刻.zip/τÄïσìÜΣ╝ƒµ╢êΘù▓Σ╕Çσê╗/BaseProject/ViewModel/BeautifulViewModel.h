//
//  BeautifulViewModel.h
//  BaseProject
//
//  Created by tarena on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "BeautifulNetManager.h"
@interface BeautifulViewModel : BaseViewModel
@property(nonatomic) NSInteger rowNumber;

- (NSURL *)iconForRow:(NSInteger)row;
- (void)refreshDataCompleteHandle:(void(^)(NSError *error))complete;
- (void)getMoreDataCompleteHandle:(void(^)(NSError *error))complete;

@property(nonatomic) NSInteger page;
@end
